//Import some assets from Vortex we'll need.
const path = require('path');
const { fs, log, util } = require('vortex-api');

const GAME_ID = 'eft-singleplayertarkov';	//Name of the folder that Vortex will use for SPT in the Staging and Downloading Folders
const GAME_ARTWORK = 'gameart.png';
const GAME_NAME = 'Escape From Tarkov: Single Player Tarkov';
const MOD_PATH = './';

//*		Main Function
function main(context) //This is the main function Vortex will run when detecting the game extension.
{	
	context.registerGame
	(
		{
			id: GAME_ID,
			name: GAME_NAME,
			mergeMods: true,
			supportedTools:
			[
				{	//SPT Server Exe Shortcut added to Toolbar
					id: 'SPT-Server',
					name: 'SPT Server',
					logo: 'SPT-Server.ico',
					queryPath: () => './',
					executable: () => 'SPT.Server.exe',
					requiredFiles: ['SPT.Server.exe',],
					relative: true,
					shell: true,							//The server needs to be run as a powershell to function
				},
				{	//SPT Launcher Exe Shortcut added to Toolbar
					id: 'SPT-Launcher',
					name: 'SPT Launcher',
					logo: 'SPT-Launcher.ico',
					queryPath: () => './',
					executable: () => 'SPT.Launcher.exe',
					requiredFiles: ['SPT.Launcher.exe',],
					relative: true,
					//shell: true,
				},
				{	//Server Value Manager Exe Shortcut added to Toolbar, https://hub.sp-tarkov.com/files/file/379-server-value-modifier-svm/
					id: 'SVM-Greed',
					name: 'Server Value Modifier',
					logo: 'Greed.ico',
					queryPath: () => 'user/mods/[SVM] Server Value Modifier',
					executable: () => 'Greed.exe',
					requiredFiles: ['Greed.exe',],
					relative: true,
					exclusive: true,
				},
				{	//Acid's Bot Placement System Exe Shortcut added to Toolbar, https://hub.sp-tarkov.com/files/file/2782-abps-acid-s-bot-placement-system/
					id: 'ABPSConfig',
					name: 'ABPS - Acid\'s Bot Placement System',
					logo: 'ABPSConfig.ico',
					queryPath: () => 'user/mods/acidphantasm-botplacementsystem',
					executable: () => 'ABPSConfig.exe',
					requiredFiles: ['ABPSConfig.exe',],
					relative: true,
					exclusive: true,
				},
				{	//Load Order Editor Drag-Drop Exe Shortcut added to Toolbar, https://hub.sp-tarkov.com/files/file/1923-load-order-editor-drag-drop/
					id: 'LoEDD',
					name: 'Load Order Editor Drag-Drop',
					logo: 'LoEDD.ico',
					queryPath: () => 'LoEDD',
					executable: () => 'LoEDD.exe',
					requiredFiles: ['LoEDD.exe',],
					relative: true,
					exclusive: true,
				},
				{	//Load Order Editor Exe Shortcut added to Toolbar, https://hub.sp-tarkov.com/files/file/1082-loe-load-order-editor/
					id: 'LOE',
					name: 'Load Order Editor',
					logo: 'Load Order Editor.ico',
					queryPath: () => 'user/mods',
					executable: () => 'Load Order Editor.exe',
					requiredFiles: ['Load Order Editor.exe',],
					relative: true,
					exclusive: true,
				}
			],
			queryModPath: () => './',
			logo: GAME_ARTWORK,
			executable: () => 'SPT.Launcher.exe',
			requiredFiles: 
				[
				  'EscapeFromTarkov.exe',	//Escape From Tarkov Base Game executable
				  'SPT.Server.exe',			//Single Player Tarkov Server executable
				  'SPT.Launcher.exe'		//Single Player Tarkov Single Player Launcher executable
				],
		}
	);
	return true
}
//*/	// Main Function

module.exports = {default: main,};